var sales = [{
    "manufacturer": "五谷道场",
    "id": 1001,
    "sampleId": "20070528761",
    "name": "庖丁时蔬",
    "specification": "袋装75g",
    "if_widen": "加宽"
},{
    "manufacturer": "五谷道场",
    "id": 1002,
    "sampleId": "20070810671",
    "name": "西红柿牛腩",
    "specification": "袋装75g",
    "if_widen": "加宽"
},{
    "manufacturer": "五谷道场",
    "id": 1003,
    "sampleId": "20071025262",
    "name": "酱香排骨",
    "specification": "袋装75g",
    "if_widen": "加宽"
},{
    "manufacturer": "今麦郎",
    "id": 1007,
    "sampleId": "200706201035 ",
    "name": "四川麻辣牛肉味",
    "specification": "桶装90g",
    "if_widen": ""
},{
    "manufacturer": "康师傅",
    "id": 1015,
    "sampleId": "20070917102",
    "name": "烧烤牛肉面",
    "specification": "袋装90g",
    "if_widen": ""
},{
    "manufacturer": "康师傅",
    "id": 1013,
    "sampleId": "20070625111",
    "name": "红烧牛肉面",
    "specification": "袋装90g",
    "if_widen": ""
},{
    "manufacturer": "白象",
    "id": 1019,
    "sampleId": "200706272",
    "name": "大骨面-酱香猪骨味",
    "specification": "袋装86g",
    "if_widen": ""
}
];